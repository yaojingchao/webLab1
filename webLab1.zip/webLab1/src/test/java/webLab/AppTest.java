package test.webLab; 

import junit.framework.Test; 
import junit.framework.TestSuite; 
import junit.framework.TestCase; 

/** 
* App Tester. 
* 
* @author <Authors name> 
* @since <pre>04/14/2020</pre> 
* @version 1.0 
*/ 
public class AppTest extends TestCase { 
public AppTest(String name) { 
super(name); 
} 

public void setUp() throws Exception { 
super.setUp(); 
} 

public void tearDown() throws Exception { 
super.tearDown(); 
} 

/** 
* 
* Method: main(String[] args) 
* 
*/ 
public void testMain() throws Exception { 
//TODO: Test goes here... 
} 



public static Test suite() { 
return new TestSuite(AppTest.class); 
} 
} 
